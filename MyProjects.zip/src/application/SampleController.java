package application;

import java.io.*;
import java.net.URL;
import java.text.MessageFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.naming.Context;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextArea;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;

public class SampleController implements Initializable {
	@FXML
	private TextArea textArea;

	@FXML
	private Menu menu_file;

	@FXML
	private MenuItem menuItem_open, menuItem_save, menuItem_exit;
	
	@FXML
	private Label dateTime;

	// ����(�޴� ����)
	public void selectSave(ActionEvent event) {
		System.out.println("Save");

		// FileChooser dialog ����
		FileChooser fileChooser = new FileChooser();
		FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("TXT files (*.txt)", "*.txt");
		fileChooser.getExtensionFilters().add(extFilter);

		// dialog ���̱�
		File file = fileChooser.showSaveDialog(null);

		if (file != null) {
			saveFile(file);
		}
	}

	// ����(�޼ҵ�)
	private void saveFile(File file) {
		try {
			FileWriter fw = null;
			fw = new FileWriter(file);
			fw.write(textArea.getText().replaceAll("\n", "\r\n"));
			fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// ����(�޴� ����)
	public void selectOpen(ActionEvent event) {
		System.out.println("Open");

		FileChooser fileChooser = new FileChooser();

		// FileChooser dialog ����
		FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("TXT files (*.txt)", "*.txt");
		fileChooser.getExtensionFilters().add(extFilter);

		// dialog ���̱�
		File file = fileChooser.showOpenDialog(null);
		if (file != null) {
			textArea.setText(readFile(file));
		}
	}

	// ����(�޼ҵ�)
	private String readFile(File file) {
		StringBuilder stringBuffer = new StringBuilder();
		BufferedReader bufferedReader = null;

		try {
			bufferedReader = new BufferedReader(new FileReader(file));

			String text;
			while ((text = bufferedReader.readLine()) != null) {
				stringBuffer.append(text);
			}

		} catch (FileNotFoundException ex) {
			Logger.getLogger(SampleController.class.getName()).log(Level.SEVERE, null, ex);
		} catch (IOException ex) {
			Logger.getLogger(SampleController.class.getName()).log(Level.SEVERE, null, ex);
		} finally {
			try {
				bufferedReader.close();
			} catch (IOException ex) {
				Logger.getLogger(SampleController.class.getName()).log(Level.SEVERE, null, ex);
			}
		}

		return stringBuffer.toString();
	}

	// �ݱ�
	public void selectExit(ActionEvent event) {
		System.out.println("Exit NotePad");
		System.exit(0);
	}

	// implements Initializable�� ���� ����Ǵ� �ʱ� �۾�
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		Thread thread = new Thread() { // ���ٽ�
			public void run() {

				while (true) {
					try {
						Date now = Calendar.getInstance().getTime();
						String s = MessageFormat.format("{0,date,yyy-MM-dd HH:mm:ss}", now);

						// ����ó��(���� �켱 ����)
						Platform.runLater(() -> {
							dateTime.setText(s);
						});

						Thread.sleep(1000);

						// System.out.println(s);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}

			}
		};

		thread.start();

	}
}
